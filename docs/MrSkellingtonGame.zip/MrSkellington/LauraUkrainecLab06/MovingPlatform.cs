﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class MovingPlatform : Platform
    {
        protected float speed = 50,
                        minY = 530, //according to screen
                        maxY = 150;
        protected Vector2 direction = new Vector2(0, 1),
                          velocity;

        public MovingPlatform(Vector2 position, Vector2 dimensions) : base(position, dimensions)
        {
            this.position = position;
            this.dimensions = dimensions;
        }

        internal override void LoadContent(ContentManager content)
        {
            base.LoadContent(content);
            texture = content.Load<Texture2D>("Elevator");
        }

        internal void Update(GameTime gameTime)
        {
            velocity = direction * speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            position += velocity;
            foreach (Collider c in colliders)
            {
                c.Move(velocity);
            }
            if (position.Y > minY || position.Y < maxY)
            {
                direction *= -1;
            }
        }
    }
}
