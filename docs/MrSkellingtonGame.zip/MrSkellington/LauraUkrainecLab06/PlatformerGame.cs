﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace LauraUkrainecLab06
{
    public class PlatformerGame : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        protected enum GameState
        {
            Start,
            Playing,
            End
        }
        protected GameState gameState;

        internal const int Gravity = 5;

        protected const int WindowWidth = 760,
                            WindowHeight = 600,
                            numCollectibles = 10,
                            numPlatforms = 6;
        protected Texture2D background,
                            startScreen,
                            endScreen;
        protected Rectangle gameBoundingBox = new Rectangle(0, 0, WindowWidth, WindowHeight);

        protected Player player;
        protected MovingPlatform elevator;

        protected Collectible[] collectibles;
        protected Collider[] colliders;
        protected Platform[] platforms;
        protected Vector2 platformDimens = new Vector2(128, 64);

        public PlatformerGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = WindowWidth;
            graphics.PreferredBackBufferHeight = WindowHeight;
            graphics.ApplyChanges();

            gameState = GameState.Start;
            player = new Player(new Vector2(255, 508), gameBoundingBox);
            elevator = new MovingPlatform(new Vector2(588, 172), new Vector2(112, 26));

            collectibles = new Collectible[numCollectibles];
            collectibles[0] = new Collectible(new Vector2(76, 140));
            collectibles[1] = new Collectible(new Vector2(252, 76));
            collectibles[2] = new Collectible(new Vector2(444, 140));
            collectibles[3] = new Collectible(new Vector2(623, 76));
            collectibles[4] = new Collectible(new Vector2(172, 236));
            collectibles[5] = new Collectible(new Vector2(332, 236));
            collectibles[6] = new Collectible(new Vector2(252, 332));
            collectibles[7] = new Collectible(new Vector2(76, 396));
            collectibles[8] = new Collectible(new Vector2(444, 396));
            collectibles[9] = new Collectible(new Vector2(76, 523));

            colliders = new Collider[5];
            colliders[0] = new ColliderTop(new Vector2(0, 556), new Vector2(WindowWidth, 1)); //ground
            colliders[1] = new ColliderBottom(new Vector2(0, 44), new Vector2(WindowWidth, 1)); //screenTop
            colliders[2] = new ColliderRight(new Vector2(44, 0), new Vector2(1, WindowHeight)); //screenLeft
            colliders[3] = new ColliderLeft(new Vector2(689, 0), new Vector2(1, WindowHeight)); //screenRight
            colliders[4] = new ColliderLeft(new Vector2(588, 546), new Vector2(1, 10)); //underElevator


            platforms = new Platform[numPlatforms];
            platforms[0] = new Platform(new Vector2(12, 172), platformDimens);
            platforms[1] = new Platform(new Vector2(204, 108), platformDimens);
            platforms[2] = new Platform(new Vector2(396, 172), platformDimens);
            platforms[3] = new Platform(new Vector2(12, 428), platformDimens);
            platforms[4] = new Platform(new Vector2(204, 364), platformDimens);
            platforms[5] = new Platform(new Vector2(396, 428), platformDimens);

            base.Initialize();
            player.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            background = Content.Load<Texture2D>("Background");
            startScreen = Content.Load<Texture2D>("StartScreen");
            endScreen = Content.Load<Texture2D>("EndScreen");

            player.LoadContent(Content);
            elevator.LoadContent(Content);
            foreach (Collectible cb in collectibles)
            {
                cb.LoadContent(Content);
            }
            foreach (Collider c in colliders)
            {
                c.LoadContent(Content);
            }
            foreach (Platform p in platforms)
            {
                p.LoadContent(Content);
            }
        }

        protected override void Update(GameTime gameTime)
        {
            KeyboardState kbState = Keyboard.GetState();
            
            switch (gameState)
            {
                case GameState.Start:
                    if (kbState.IsKeyDown(Keys.Enter))
                    {
                        gameState = GameState.Playing;
                    }
                    break;
                case GameState.Playing:
                    int numCollected = 0;

                    if (kbState.IsKeyDown(Keys.Left))
                    {
                        if (player.FacingRight)
                        {
                            player.Flip();
                        }
                        player.MoveHorizontally(-1);
                    }
                    else if (kbState.IsKeyDown(Keys.Right))
                    {
                        if (!player.FacingRight)
                        {
                            player.Flip();
                        }
                        player.MoveHorizontally(1);
                    }
                    else
                    {
                        player.Stop();
                    }
                    if (kbState.IsKeyDown(Keys.Space))
                    {
                        player.Jump();
                    }

                    elevator.ProcessCollisions(player);
                    foreach (Collectible cb in collectibles)
                    {
                        if (cb.state == Collectible.State.Ready)
                        {
                            cb.ProcessCollisions(player);
                        }
                        else
                        {
                            numCollected++;
                        }

                    }
                    foreach (Collider c in colliders)
                    {
                        c.ProcessCollisions(player);
                    }
                    foreach (Platform p in platforms)
                    {
                        p.ProcessCollisions(player);
                    }

                    if (numCollected == numCollectibles)
                    {
                        gameState = GameState.End;
                    }

                    elevator.Update(gameTime);
                    player.Update(gameTime);
                    base.Update(gameTime);
                    break;
                case GameState.End:
                    if (kbState.IsKeyDown(Keys.R))
                    {
                        player.Position = new Vector2(255, 508);
                        foreach (Collectible cb in collectibles)
                        {
                            cb.state = Collectible.State.Ready;
                        }
                        gameState = GameState.Start;
                    }
                    break;
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Purple);

            spriteBatch.Begin();
            switch (gameState)
            {
                case GameState.Start:
                    spriteBatch.Draw(startScreen, Vector2.Zero, Color.White);
                    break;
                case GameState.Playing:
                    foreach (Platform platform in platforms)
                    {
                        platform.Draw(spriteBatch);
                    }
                    spriteBatch.Draw(background, Vector2.Zero, Color.White);
                    player.Draw(spriteBatch);
                    elevator.Draw(spriteBatch);
                    foreach (Collectible cb in collectibles)
                    {
                        cb.Draw(spriteBatch);
                    }
                    break;
                case GameState.End:
                    spriteBatch.Draw(endScreen, Vector2.Zero, Color.White);
                    break;
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}