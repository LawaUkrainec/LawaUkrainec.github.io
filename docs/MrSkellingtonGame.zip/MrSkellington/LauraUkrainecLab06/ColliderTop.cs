﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class ColliderTop : Collider
    {
        public ColliderTop(Vector2 position, Vector2 dimensions) : base(position, dimensions)
        {
        }

        internal override void ProcessCollisions(Player player)
        {
            if (BoundingBox.Intersects(player.BoundingBox))
            {
                player.Land(BoundingBox);
                player.StandOn();
            }
        }
    }
}