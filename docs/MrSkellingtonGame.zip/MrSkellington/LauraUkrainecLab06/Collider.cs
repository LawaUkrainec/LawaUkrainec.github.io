﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public abstract class Collider
    {
        protected Texture2D texture;
        protected Vector2 position,
                          dimensions;

        internal Rectangle BoundingBox
        {
            get
            {
                return new Rectangle((int)position.X, (int)position.Y,
                                      (int)dimensions.X, (int)dimensions.Y);
            }
        }

        public Collider(Vector2 position, Vector2 dimensions)
        {
            this.position = position;
            this.dimensions = dimensions;
        }

        internal void LoadContent(ContentManager Content)
        {
            texture = Content.Load<Texture2D>("Collider");
        }

        internal void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, BoundingBox, new Rectangle(0, 0, 1, 1), Color.White);
        }

        internal abstract void ProcessCollisions(Player player);

        internal void Move(Vector2 movement)
        {
            this.position += movement;
        }
    }
}
