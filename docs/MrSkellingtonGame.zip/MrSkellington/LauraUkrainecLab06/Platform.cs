﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class Platform
    {
        protected Texture2D texture;
        protected Vector2 position,
                          dimensions;
        protected int numColliders = 4;

        protected Player player;
        protected Collider[] colliders;

        internal bool drawColliders = false;

        internal Rectangle BoundingBox
        {
            get
            {
                return new Rectangle((int)position.X, (int)position.Y,
                                     (int)dimensions.X, (int)dimensions.Y);
            }
        }

        public Platform(Vector2 position, Vector2 dimensions)
        {
            this.position = position;
            this.dimensions = dimensions;

            colliders = new Collider[numColliders];
            colliders[0] = new ColliderTop(
                new Vector2(position.X + 3, position.Y),
                new Vector2(dimensions.X - 6, 1));
            colliders[1] = new ColliderRight(
                new Vector2(position.X + dimensions.X - 1, position.Y + 1),
                new Vector2(1, dimensions.Y - 2));
            colliders[2] = new ColliderBottom(
                new Vector2(position.X + 3, position.Y + dimensions.Y),
                new Vector2(dimensions.X - 6, 1));
            colliders[3] = new ColliderLeft(
                new Vector2(position.X, position.Y + 1),
                new Vector2(1, dimensions.Y - 2));
        }

        internal virtual void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("Platform");
            foreach (Collider c in colliders)
            {
                c.LoadContent(content);
            }
        }

        internal void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, Color.White);
        }

        internal void ProcessCollisions(Player player)
        {
            foreach (Collider c in colliders)
            {
                c.ProcessCollisions(player);
            }
        }
    }
}
