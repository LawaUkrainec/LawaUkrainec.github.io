﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class Player
    {
        protected enum State
        {
            Idle,
            Walking,
            Jumping
        }
        protected State state;

        protected CelAnimationPlayer animationPlayer;
        protected CelAnimationSequence idleSequence,
                                       jumpSequence,
                                       walkSequence;
        
        protected Vector2 position,
                          velocity;

        internal Vector2 Position
        {
            get { return position; }
            set { position = value; }
        }
        internal Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = value; }
        }

        protected bool facingRight;
        internal bool FacingRight
        {
            get { return facingRight; }
            set { facingRight = value; }
        }

        protected Rectangle gameBoundingBox;
        protected Vector2 dimensions;

        protected SpriteEffects effect;

        protected const int Speed = 100,
                            JumpSpeed = -200;

        internal Rectangle BoundingBox
        {
            get
            {
                return new Rectangle((int)position.X, (int)position.Y, (int)dimensions.X, (int)dimensions.Y);
            }
        }

        public Player(Vector2 position, Rectangle gameBoundingBox)
        {
            this.position = position;
            this.gameBoundingBox = gameBoundingBox;
            dimensions = new Vector2(35, 50);
            animationPlayer = new CelAnimationPlayer();
        }

        internal void Initialize()
        {
            state = State.Idle;
            facingRight = true;
            effect = SpriteEffects.None;
            animationPlayer.Play(idleSequence);
        }

        internal void LoadContent(ContentManager Content)
        {
            idleSequence = new CelAnimationSequence(Content.Load<Texture2D>("SkeletonIdle"), 35, 1 / 8f);
            walkSequence = new CelAnimationSequence(Content.Load<Texture2D>("SkeletonWalk"), 35, 1 / 8f);
            jumpSequence = new CelAnimationSequence(Content.Load<Texture2D>("SkeletonJump"), 35, 1 / 8f);
        }

        internal void Update(GameTime GameTime)
        {
            switch (state)
            {
                case State.Jumping:
                case State.Idle:
                    animationPlayer.PlayOnce(GameTime);
                    break;
                case State.Walking:
                    animationPlayer.Update(GameTime);
                    break;
            }
            position += velocity * (float)GameTime.ElapsedGameTime.TotalSeconds;
            velocity.Y += PlatformerGame.Gravity;

            if (Math.Abs(velocity.Y) != 0)
            {
                state = State.Jumping;
            }
        }

        internal void Draw(SpriteBatch SpriteBatch)
        {
            switch (state)
            {
                case State.Jumping:
                case State.Idle:
                case State.Walking:
                    animationPlayer.Draw(SpriteBatch, position, effect);
                    break;
            }
        }

        internal void Flip()
        {
            if (facingRight)
            {
                effect = SpriteEffects.FlipHorizontally;
                facingRight = false;
            }
            else
            {
                effect = SpriteEffects.None;
                facingRight = true;
            }
        }

        internal void Move(Vector2 direction)
        {
            velocity.X = direction.X * Speed;
            if (state == State.Idle)
            {
                state = State.Walking;
                animationPlayer.Play(walkSequence);
            }
        }

        internal void MoveHorizontally(float direction)
        {
            velocity.X = direction * Speed;
            animationPlayer.Play(walkSequence);
        }

        internal void MoveVertically(float direction)
        {
            velocity.Y = direction * Speed;
            animationPlayer.Play(walkSequence);
        }

        internal void Stop()
        {
            if (state == State.Walking)
            {
                velocity = Vector2.Zero;
                state = State.Idle;
                animationPlayer.Play(idleSequence);
            }
        }

        internal void Jump()
        {
            if (state != State.Jumping)
            {
                animationPlayer.Play(jumpSequence);
                velocity.Y = JumpSpeed;
            }
        }

        internal void Airborne()
        {
            if (state != State.Jumping)
            {
                velocity.Y = -200;
            }
        }

        internal void Land(Rectangle whatILandedOn)
        {
            position.Y = whatILandedOn.Top - dimensions.Y + 1;
            if (state == State.Jumping)
            {
                velocity.Y = 0;
                state = State.Walking;
            }
        }

        internal void StandOn()
        {
            velocity.Y -= PlatformerGame.Gravity;
        }
    }
}
