﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class Collectible
    {
        internal enum State
        {
            Ready,
            Collected
        }
        internal State state;

        protected Texture2D texture;
        protected Vector2 position,
                          dimensions = new Vector2(32, 32);

        internal Rectangle BoundingBox
        {
            get
            {
                return new Rectangle((int)position.X, (int)position.Y, (int)dimensions.X, (int)dimensions.Y);
            }
        }

        public Collectible(Vector2 position)
        {
            this.position = position;
            state = State.Ready;
        }

        internal void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("Milk");
        }

        internal void Draw(SpriteBatch spriteBatch)
        {
            if (state == State.Ready)
            {
                spriteBatch.Draw(texture, position, Color.White);
            }
        }

        internal void ProcessCollisions(Player player)
        {
            if (BoundingBox.Intersects(player.BoundingBox))
            {
                state = State.Collected;
            }
        }
    }
}
