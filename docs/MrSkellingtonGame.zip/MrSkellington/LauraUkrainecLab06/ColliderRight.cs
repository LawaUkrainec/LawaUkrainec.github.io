﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class ColliderRight : Collider
    {
        public ColliderRight(Vector2 position, Vector2 dimensions) : base(position, dimensions)
        {
        }

        internal override void ProcessCollisions(Player player)
        {
            if (BoundingBox.Intersects(player.BoundingBox))
            {
                if (player.Velocity.X < 0)
                {
                    player.MoveHorizontally(0);
                }
            }
        }
    }
}