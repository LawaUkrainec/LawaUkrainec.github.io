﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace LauraUkrainecLab06
{
    public class ColliderBottom : Collider
    {
        public ColliderBottom(Vector2 position, Vector2 dimensions) : base(position, dimensions)
        {
        }

        internal override void ProcessCollisions(Player player)
        {
            if (BoundingBox.Intersects(player.BoundingBox))
            {
                if (player.Velocity.Y < 0)
                {
                    player.MoveVertically(0);
                }
            }
        }
    }
}